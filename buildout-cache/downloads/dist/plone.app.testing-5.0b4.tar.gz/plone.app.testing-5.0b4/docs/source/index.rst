.. plone.app.testing documentation master file, created by
   sphinx-quickstart on Sat Feb  9 11:31:41 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to plone.app.testing's documentation!
=============================================

.. toctree::
   :maxdepth: 2

   README
   views
   zope-testbrowser



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

