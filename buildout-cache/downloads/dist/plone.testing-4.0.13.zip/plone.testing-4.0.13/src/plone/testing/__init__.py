# Convenience imports

from plone.testing.layer import (
        Layer,
        layered
    )
