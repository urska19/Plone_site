The <packagename>.po file containing language-specific translations for your
product will go here when it is generated.

For more information on internationalization and the difference between the
i18n directory and this locales directory, read here:

http://maurits.vanrees.org/weblog/archive/2010/10/i18n-plone-4

or a version that may be partly more accurate for Plone 3.2 or earlier:

http://maurits.vanrees.org/weblog/archive/2007/09/i18n-locales-and-plone-3.0
