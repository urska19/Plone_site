Known plone.app.robotframework-examples
=======================================

A minimal example **plone.app.robotramework**-example:

- https://github.com/datakurre/example.product/tree/p.a.robotframework
- https://travis-ci.org/datakurre/example.product
- https://saucelabs.com/u/exampleproduct

This is how we used this for Plomino to run some robot tests at SauceLabs:

- https://github.com/plomino/Plomino/pull/322/files
- https://travis-ci.org/fulv/Plomino
- https://saucelabs.com/u/fulv_plomino

More examples which already contain robotframework tests in collective:

- https://github.com/collective/collective.wfcomment
  (checking prepOverlays)
- https://github.com/collective/collective.prettyphoto
- https://github.com/collective/plone.app.imagecropping
  (includes javascript interaction in cropping editor).
- https://github.com/plone/plone.app.robotframework/tree/master/src/plone/app/robotframework/tests
- http://plone.293351.n2.nabble.com/Robot-Framework-How-to-fill-TinyMCE-s-text-field-tp7563662p7563691.html
