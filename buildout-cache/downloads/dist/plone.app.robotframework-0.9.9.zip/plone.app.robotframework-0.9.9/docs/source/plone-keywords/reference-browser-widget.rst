==============================================================================
Reference Browser Widget Keywords
==============================================================================

Set Reference Browser Field Value::

    Set reference browser field value

    [arguments]  ${fieldName}  @{path}


Checkbox Select::

    Select checkbox (check it)

    [arguments]  ${title}
